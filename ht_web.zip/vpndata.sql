-- phpMyAdmin SQL Dump
-- version 4.7.0-beta1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: 2018-11-18 20:32:49
-- 服务器版本： 5.5.60-MariaDB
-- PHP Version: 7.0.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `haosky`
--

-- --------------------------------------------------------

--
-- 表的结构 `app_admin`
--

CREATE TABLE `app_admin` (
  `id` int(11) NOT NULL,
  `op` text NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_admin`
--

INSERT INTO `app_admin` (`id`, `op`, `username`, `password`) VALUES
(1, '0', 'lyfasadmin', 'lyfaspass');

-- --------------------------------------------------------

--
-- 表的结构 `app_bbs`
--

CREATE TABLE `app_bbs` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `username` text NOT NULL,
  `to` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_bbs`
--

INSERT INTO `app_bbs` (`id`, `name`, `content`, `time`, `username`, `to`) VALUES
(1, '', '啦啦啦啦啦啦啦', '1486670176', '18233360137', '0');

-- --------------------------------------------------------

--
-- 表的结构 `app_config`
--

CREATE TABLE `app_config` (
  `id` int(11) NOT NULL,
  `system` text NOT NULL,
  `qq` text NOT NULL,
  `top_content` text NOT NULL,
  `no_limit` text NOT NULL,
  `reg` int(11) NOT NULL,
  `col1` text NOT NULL,
  `col2` text NOT NULL,
  `col3` text NOT NULL,
  `col4` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `app_daili`
--

CREATE TABLE `app_daili` (
  `id` int(11) NOT NULL,
  `qq` text NOT NULL COMMENT 'qq',
  `content` text,
  `type` int(11) DEFAULT '1' COMMENT '代理等级',
  `balance` text NOT NULL COMMENT '（元）',
  `name` text NOT NULL,
  `pass` text NOT NULL,
  `lock` int(11) NOT NULL,
  `endtime` int(11) NOT NULL,
  `time` int(22) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `app_daili_type`
--

CREATE TABLE `app_daili_type` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `per` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_daili_type`
--

INSERT INTO `app_daili_type` (`id`, `name`, `per`) VALUES
(1, 'VIP1', 80),
(2, 'VIP2', 75);

-- --------------------------------------------------------

--
-- 表的结构 `app_data`
--

CREATE TABLE `app_data` (
  `id` int(11) NOT NULL,
  `key` char(255) NOT NULL,
  `value` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `app_feedback`
--

CREATE TABLE `app_feedback` (
  `id` int(11) NOT NULL,
  `line_id` int(11) NOT NULL,
  `content` text COLLATE utf8_bin NOT NULL,
  `user_id` int(11) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- 表的结构 `app_gg`
--

CREATE TABLE `app_gg` (
  `id` int(11) NOT NULL,
  `daili` int(11) DEFAULT '0',
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_gg`
--

INSERT INTO `app_gg` (`id`, `daili`, `name`, `content`, `time`) VALUES
(1, 0, '欢迎使用浩天加速器', '浩天加速器，欢迎您的使用!', '1528041043');

-- --------------------------------------------------------

--
-- 表的结构 `app_kms`
--

CREATE TABLE `app_kms` (
  `id` int(11) NOT NULL,
  `daili` int(11) DEFAULT '0',
  `km` varchar(64) DEFAULT NULL,
  `isuse` tinyint(1) DEFAULT '0',
  `user_id` int(50) DEFAULT NULL,
  `usetime` int(11) DEFAULT NULL,
  `addtime` int(11) DEFAULT NULL,
  `type_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `app_note`
--

CREATE TABLE `app_note` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `description` text NOT NULL,
  `count` int(11) NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_note`
--

INSERT INTO `app_note` (`id`, `name`, `ipport`, `time`, `description`, `count`, `order`) VALUES
(1, '游戏节点（刺激&amp;CFM）', '服务器IP', '2018-10-31 16:00:00', '不限速/玩游戏', 100, 1);

-- --------------------------------------------------------

--
-- 表的结构 `app_order`
--

CREATE TABLE `app_order` (
  `id` int(11) NOT NULL,
  `payid` varchar(32) COLLATE utf8mb4_bin NOT NULL,
  `order` varchar(22) COLLATE utf8mb4_bin NOT NULL,
  `pay` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  `status_time` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- --------------------------------------------------------

--
-- 表的结构 `app_read`
--

CREATE TABLE `app_read` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `readid` text NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_read`
--

INSERT INTO `app_read` (`id`, `username`, `readid`, `time`) VALUES
(1, '123456', '2', '1486721103'),
(2, '18233360137', '2', '1487559081');

-- --------------------------------------------------------

--
-- 表的结构 `app_tc`
--

CREATE TABLE `app_tc` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `content` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `time` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `jg` text NOT NULL,
  `limit` text NOT NULL,
  `rate` text NOT NULL COMMENT '（单位M）',
  `url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `app_tc`
--

INSERT INTO `app_tc` (`id`, `name`, `content`, `time`, `jg`, `limit`, `rate`, `url`) VALUES
(3, '30day', '【套餐内容】\r\n30天不限流量包月套餐\r\n【价格】\r\n30元/月', '1488272300', '30', '30', '102400', 'http://pubgld.ml');

-- --------------------------------------------------------

--
-- 表的结构 `auth_fwq`
--

CREATE TABLE `auth_fwq` (
  `id` int(11) NOT NULL,
  `name` varchar(32) NOT NULL,
  `ipport` varchar(64) NOT NULL,
  `time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `auth_fwq`
--

INSERT INTO `auth_fwq` (`id`, `name`, `ipport`, `time`) VALUES
(4, '默认服务器', '服务器IP:8888', '2018-11-18 16:49:55');

-- --------------------------------------------------------

--
-- 表的结构 `line`
--

CREATE TABLE `line` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `content` text NOT NULL,
  `type` text NOT NULL,
  `group` text NOT NULL,
  `show` int(11) NOT NULL,
  `label` text NOT NULL,
  `order` int(11) NOT NULL DEFAULT '0',
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `line`
--

INSERT INTO `line` (`id`, `name`, `content`, `type`, `group`, `show`, `label`, `order`, `time`) VALUES
(1, '防封线路③', '#欢迎使用PUBG平哥流控\r\n#欢迎访问我们的官网：www.pubgld.ml\r\n#联系QQ:1437284361\r\nclient\r\ndev tun\r\nproto tcp\r\nremote [domain] 443\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot;\r\npush route 223.5.5.5 223.6.6.6\r\nmachine-readable-output\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3\r\n## 证书\r\n&lt;ca&gt;\r\n[证书]\r\n&lt;/ca&gt;\r\nkey-direction 1\r\n&lt;tls-auth&gt;\r\n[证书]\r\n&lt;/tls-auth&gt;\r\n', 'TCP防封', '1', 1, '防封线路', 0, '1541084089'),
(2, '防封线路②', '#欢迎使用PUBG平哥流控\r\n#欢迎访问我们的官网：www.pubgld.ml\r\n#联系QQ:1437284361\r\nclient\r\ndev tun\r\nproto tcp\r\nremote [domain] 1024\r\nhttp-proxy [domain] 8080\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot;\r\npush route 114.114.114.144 114.114.115.115\r\nmachine-readable-output\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3\r\n## 证书\r\n&lt;ca&gt;\r\n[证书]\r\n&lt;/ca&gt;\r\nkey-direction 1\r\n&lt;tls-auth&gt;\r\n[证书]\r\n&lt;/tls-auth&gt;', 'TCP防封', '1', 1, '防封线路', 0, '1541084089'),
(3, '防封线路①', '#欢迎使用PUBG平哥流控\r\n#欢迎访问我们的官网：www.pubgld.ml\r\n#联系QQ:1437284361\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot;\r\nmachine-readable-output\r\nclient\r\ndev tun\r\nproto udp\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\nremote  [domain]\r\npush route 223.5.5.5 223.6.6.6\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3\r\n## 证书\r\n&lt;ca&gt;\r\n[证书]\r\n&lt;/ca&gt;\r\nkey-direction 1\r\n&lt;tls-auth&gt;\r\n[证书]\r\n&lt;/tls-auth&gt;', 'TCP防封', '1', 1, '防封线路', 0, '1541084089'),
(4, '防封UDP 【CFM】', '#欢迎使用PUBG平哥流控\r\n#欢迎访问我们的官网：www.pubgld.ml\r\n#联系QQ:1437284361\r\nclient\r\ndev tun\r\nproto udp\r\nremote  [domain] 53\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot;\r\npush route 114.114.114.144 114.114.115.115\r\nmachine-readable-output\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3\r\n\r\n## 证书\r\n&lt;ca&gt;\r\n[证书]\r\n&lt;/ca&gt;\r\nkey-direction 1\r\n&lt;tls-auth&gt;\r\n[证书]\r\n&lt;/tls-auth&gt;', 'UDP防封', '1', 1, '防封线路', 0, '1541084089'),
(5, '防封TCP 【吃鸡】', '#欢迎使用PUBG平哥流控\r\n#欢迎访问我们的官网：www.pubgld.ml\r\n#联系QQ:1437284361\r\nclient\r\ndev tun\r\nproto tcp\r\nremote [domain] 80\r\nhttp-proxy [domain] 8080\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot;\r\npush route 114.114.114.144 114.114.115.115\r\nmachine-readable-output\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3\r\n## 证书\r\n&lt;ca&gt;\r\n[证书]\r\n&lt;/ca&gt;\r\nkey-direction 1\r\n&lt;tls-auth&gt;\r\n[证书]\r\n&lt;/tls-auth&gt;', 'TCP防封', '1', 1, '防封线路', 0, '1541084089'),
(6, '新防封TCP 【推荐】', '#欢迎使用PUBG平哥流控\r\n#欢迎访问我们的官网：www.pubgld.ml\r\n#联系QQ:1437284361\r\nclient\r\ndev tun\r\nproto tcp\r\nremote [domain] 1024\r\nremote 172.168.1.1 80\r\nhttp-proxy-option EXT1 &quot;POST http://dlied1.qq.com/ HTTP/1.1&quot;\r\nhttp-proxy-option EXT1 &quot;GET http://dlied1.qq.com/ HTTP/1.1&quot;\r\nhttp-proxy-option EXT1 &quot;Host: dlied1.qq.com&quot;\r\nhttp-proxy [domain] 8080\r\nresolv-retry infinite\r\nnobind\r\npersist-key\r\npersist-tun\r\nsetenv IV_GUI_VER &quot;de.blinkt.openvpn 0.6.17&quot;\r\nmachine-readable-output\r\nconnect-retry-max 5\r\nconnect-retry 5\r\nresolv-retry 60\r\nauth-user-pass\r\nns-cert-type server\r\ncomp-lzo\r\nverb 3\r\n## 证书\r\n&lt;ca&gt;\r\n[证书]\r\n&lt;/ca&gt;\r\nkey-direction 1\r\n&lt;tls-auth&gt;\r\n[证书]\r\n&lt;/tls-auth&gt;', 'TCP防封', '1', 1, '防封线路', 0, '1541084089');

-- --------------------------------------------------------

--
-- 表的结构 `line_grop`
--

CREATE TABLE `line_grop` (
  `id` int(11) NOT NULL,
  `name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `show` int(11) NOT NULL,
  `order` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- 转存表中的数据 `line_grop`
--

INSERT INTO `line_grop` (`id`, `name`, `show`, `order`) VALUES
(1, '防封线路', 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `map`
--

CREATE TABLE `map` (
  `id` int(11) NOT NULL,
  `key` text NOT NULL,
  `value` text CHARACTER SET utf8 COLLATE utf8_bin NOT NULL,
  `type` text CHARACTER SET utf8 COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `map`
--

INSERT INTO `map` (`id`, `key`, `value`, `type`) VALUES
(1, 'versionCode', '100', 'cfg_sj'),
(2, 'url', 'http://abc.com/a.apk', 'cfg_sj'),
(3, 'content', '测试', 'cfg_sj'),
(4, 'opens', 'success', 'cfg_sj'),
(5, 'spic', '', 'cfg_sj'),
(6, 'reg_type', 'default', 'cfg_app'),
(7, 'content', '欢迎使用浩天加速器', 'cfg_app'),
(8, 'max_limit', '100', 'cfg_app'),
(9, 'SMS_T', '0', 'cfg_app'),
(10, 'SMS_L', '0', 'cfg_app'),
(11, 'SMS_I', '0', 'cfg_app'),
(12, 'Auth_Token', 'cee182005162750e23855d63ed92188d', 'cfg_app'),
(13, 'Account_Sid', '3b7004e5f782a6e4f1f195bc52990b', 'cfg_app'),
(14, 'APP_ID', 'fff126cf55e545439dfd1c16aa63d95a', 'cfg_app'),
(15, 'Template_ID', '29317', 'cfg_app'),
(16, 'APP_NAME', '浩天加速器', 'cfg_app'),
(17, 'ca', '&lt;ca&gt;\r\n-----BEGIN CERTIFICATE-----\r\nMIIE7jCCA9agAwIBAgIJAJLzuFmEowyMMA0GCSqGSIb3DQEBCwUAMIGqMQswCQYD\r\nVQQGEwJDTjELMAkGA1UECBMCQ0ExFTATBgNVBAcTDFNhbkZyYW5jaXNjbzEVMBMG\r\nA1UEChMMRm9ydC1GdW5zdG9uMRUwEwYDVQQLEwx3d3cuZGluZ2QuY24xGDAWBgNV\r\nBAMTD0ZvcnQtRnVuc3RvbiBDQTEQMA4GA1UEKRMHRWFzeVJTQTEdMBsGCSqGSIb3\r\nDQEJARYOYWRtaW5AZGluZ2QuY24wHhcNMTcwMjIxMDMzNzE4WhcNMjcwMjE5MDMz\r\nNzE4WjCBqjELMAkGA1UEBhMCQ04xCzAJBgNVBAgTAkNBMRUwEwYDVQQHEwxTYW5G\r\ncmFuY2lzY28xFTATBgNVBAoTDEZvcnQtRnVuc3RvbjEVMBMGA1UECxMMd3d3LmRp\r\nbmdkLmNuMRgwFgYDVQQDEw9Gb3J0LUZ1bnN0b24gQ0ExEDAOBgNVBCkTB0Vhc3lS\r\nU0ExHTAbBgkqhkiG9w0BCQEWDmFkbWluQGRpbmdkLmNuMIIBIjANBgkqhkiG9w0B\r\nAQEFAAOCAQ8AMIIBCgKCAQEAxShPTu6oTmHqm1pvvn/qayZ8YF26AFEct1BP8wFB\r\nIPTNxHP66c5jIqOEZjcaMwiKlngfP+cS3A8t47cW8ZZqcDguSOSiiOag+zy2iTH5\r\nHxyHaYiI2pAp55rYlx3QOXwryrBic06edD7JSGNYeXn7kOO8ViJoclOTSCCQTTJB\r\nvqNhifIy35qxcueD075Rz//dAJUhr+QX9ixtK815aSeH2+NyqYwYha3l6Z7KtFgb\r\n8veKdY9TAA4pjVX9I2iVpn+ezQPDxdBDHN4Bc8MmuIErEzVOIUxK3TzXxkSyuCSK\r\npvDFNKEITcIo2AZiPyw9OxYzfSbT3ilAzoKyEFg/WCXlxwIDAQABo4IBEzCCAQ8w\r\nHQYDVR0OBBYEFCBcOM8ljbd8B+J6Xjwj13iK7fBxMIHfBgNVHSMEgdcwgdSAFCBc\r\nOM8ljbd8B+J6Xjwj13iK7fBxoYGwpIGtMIGqMQswCQYDVQQGEwJDTjELMAkGA1UE\r\nCBMCQ0ExFTATBgNVBAcTDFNhbkZyYW5jaXNjbzEVMBMGA1UEChMMRm9ydC1GdW5z\r\ndG9uMRUwEwYDVQQLEwx3d3cuZGluZ2QuY24xGDAWBgNVBAMTD0ZvcnQtRnVuc3Rv\r\nbiBDQTEQMA4GA1UEKRMHRWFzeVJTQTEdMBsGCSqGSIb3DQEJARYOYWRtaW5AZGlu\r\nZ2QuY26CCQCS87hZhKMMjDAMBgNVHRMEBTADAQH/MA0GCSqGSIb3DQEBCwUAA4IB\r\nAQBwZvIQU4d7XD1dySjCHej+i5QhK1y2BTrmYSemLnMQp9PT/wQ7bwzZjoO9jTeJ\r\nx2sMfhp0EVQCZvBFGqArNu1Ysh00mMQfWWb8K3LWbmThEkNpwoGniHBgDkPJOITM\r\nrA2HSIh53mkQt5u9H4/vmVWElhGakgEzgfNrzxj6goX5klXxRL/JqAjAJhjS06sS\r\nJPNVSZv0tdE+XaO02sPjK7/KWbwAGf4mO2v71Q+oYJdoRmAcge+gbBMg2s6rPCfv\r\nBp2g84FhG04f5KyJIVzzQ+0sCx94XE7P5HN/zjO+3QPDd7dxGZ6ia1Z5nnSRSJVa\r\nyBNWh3h8PAaAQQi7qkuJB+iF\r\n-----END CERTIFICATE-----\r\n&lt;/ca&gt;', 'cfg_zs'),
(18, 'tls', '&lt;tls-auth&gt;\r\n-----BEGIN OpenVPN Static key V1-----\r\n07a0c4fdc79e45b6d7d69abee82a3dca\r\n7026125b063bb19d79ff443ec144dfcd\r\n6df565ad2449cb928a89f2959e32305e\r\n86cc150c1c6e1d24e25bbdbd716b0b34\r\nce5d92f5c8133812759ca8b10295d624\r\n5e6659dafbbe31fd20971b3287fc3762\r\n555cc9cd10eaf1b2570339295ded9e61\r\ncbce6d29bd8e5c7d4aea86027beb8d3c\r\n323a5dc803ef5d574b8d5c08a981ca8d\r\n3754d34a7d60896b295823cde4bb6ab7\r\n57757ab750b06352b7a218d6814ae433\r\n4a6b1570cb680cd854aad74196cda45b\r\nb69acb97de87f1ec6cc01a2034bd7e8c\r\n3e0ffea1cccf722716bcf387e56baf04\r\n369dde778a5544ada640c15c65ec5389\r\n2ba0834a78302fab9b214bfc3dddd80e\r\n-----END OpenVPN Static key V1-----\r\n&lt;/tls-auth&gt;', 'cfg_zs'),
(19, 'onoff', '1', 'cfg_zs'),
(21, 'domain', '服务器IP', 'cfg_zs'),
(22, 'LINE', 'no_abs', 'cfg_app'),
(23, 'noteoff', '1', 'cfg_app'),
(24, 'connect_unlock', '0', 'cfg_app'),
(25, 'fkurl', 'http://pubgld.ml', 'cfg_app');

-- --------------------------------------------------------

--
-- 表的结构 `openvpn`
--

CREATE TABLE `openvpn` (
  `id` int(11) NOT NULL,
  `iuser` varchar(16) NOT NULL,
  `isent` bigint(128) DEFAULT '0',
  `irecv` bigint(128) DEFAULT '0',
  `maxll` bigint(128) NOT NULL,
  `pass` varchar(18) NOT NULL,
  `i` int(1) NOT NULL,
  `starttime` varchar(30) DEFAULT NULL,
  `endtime` int(11) DEFAULT '0',
  `daili` int(11) DEFAULT '0',
  `online` int(11) DEFAULT '0',
  `old` int(11) DEFAULT '0',
  `last_ip` text,
  `proto` text,
  `login_time` int(11) NOT NULL DEFAULT '0',
  `remote_port` int(11) DEFAULT NULL,
  `note_id` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- 表的结构 `top`
--

CREATE TABLE `top` (
  `id` int(11) NOT NULL,
  `username` text NOT NULL,
  `data` bigint(20) NOT NULL,
  `time` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `top`
--

INSERT INTO `top` (`id`, `username`, `data`, `time`) VALUES
(5, '18233360137', 289780379, '2017-02-20');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_admin`
--
ALTER TABLE `app_admin`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_bbs`
--
ALTER TABLE `app_bbs`
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_config`
--
ALTER TABLE `app_config`
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_daili`
--
ALTER TABLE `app_daili`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_daili_type`
--
ALTER TABLE `app_daili_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `app_data`
--
ALTER TABLE `app_data`
  ADD UNIQUE KEY `key` (`key`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_feedback`
--
ALTER TABLE `app_feedback`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_gg`
--
ALTER TABLE `app_gg`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_3` (`id`);

--
-- Indexes for table `app_kms`
--
ALTER TABLE `app_kms`
  ADD PRIMARY KEY (`id`),
  ADD KEY `km` (`km`),
  ADD KEY `type_id` (`type_id`);

--
-- Indexes for table `app_note`
--
ALTER TABLE `app_note`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_order`
--
ALTER TABLE `app_order`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_read`
--
ALTER TABLE `app_read`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `app_tc`
--
ALTER TABLE `app_tc`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`),
  ADD KEY `id_3` (`id`);

--
-- Indexes for table `auth_fwq`
--
ALTER TABLE `auth_fwq`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `line`
--
ALTER TABLE `line`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `line_grop`
--
ALTER TABLE `line_grop`
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- Indexes for table `map`
--
ALTER TABLE `map`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `openvpn`
--
ALTER TABLE `openvpn`
  ADD PRIMARY KEY (`id`),
  ADD KEY `iuser` (`iuser`);

--
-- Indexes for table `top`
--
ALTER TABLE `top`
  ADD UNIQUE KEY `id_2` (`id`),
  ADD KEY `id` (`id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `app_bbs`
--
ALTER TABLE `app_bbs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `app_config`
--
ALTER TABLE `app_config`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `app_daili`
--
ALTER TABLE `app_daili`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `app_daili_type`
--
ALTER TABLE `app_daili_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `app_data`
--
ALTER TABLE `app_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `app_feedback`
--
ALTER TABLE `app_feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `app_gg`
--
ALTER TABLE `app_gg`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- 使用表AUTO_INCREMENT `app_kms`
--
ALTER TABLE `app_kms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1206;
--
-- 使用表AUTO_INCREMENT `app_note`
--
ALTER TABLE `app_note`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `app_order`
--
ALTER TABLE `app_order`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 使用表AUTO_INCREMENT `app_read`
--
ALTER TABLE `app_read`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `app_tc`
--
ALTER TABLE `app_tc`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `auth_fwq`
--
ALTER TABLE `auth_fwq`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- 使用表AUTO_INCREMENT `line`
--
ALTER TABLE `line`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- 使用表AUTO_INCREMENT `line_grop`
--
ALTER TABLE `line_grop`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- 使用表AUTO_INCREMENT `map`
--
ALTER TABLE `map`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
--
-- 使用表AUTO_INCREMENT `openvpn`
--
ALTER TABLE `openvpn`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- 使用表AUTO_INCREMENT `top`
--
ALTER TABLE `top`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
