<?php 


$file = '../../FAS.lock';
if(file_exists($file))
{
require ('error.php');
return;
}
else
{
echo '';
}
;echo '';
header('location:admin.php');
