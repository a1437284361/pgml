<?php 


include('head.php');
include('nav.php');
$m = new Map();
if($_GET['act'] == 'update'){
$info = file_put_contents(R.'/daili.txt',$_POST['content']);
tip_success('修改成功',$_SERVER['HTTP_REFERER']);
}else{
$action = '?act=update';
$info = file_get_contents(R.'/daili.txt');
;echo '<div class="main">
	<div class="box">
		<form class="form-horizontal" role="form" method="POST" action="';echo $action;echo '">
			<div class="form-group">
				<p>
					<span class="label label-default">代理公告/消息推送</span>
                    <div style="clear:both;height:10px;"></div>
                    <div class="alert alert-danger">公告只会在代理用户登录代理控制台时才会显示。</div>
				</p>
				
			
			</div>
			<textarea class="form-control" rows="10" name="content">';echo $info ;echo '</textarea>
			<br>
			<button type="submit" class="btn btn-info btn-block">提交数据</button>
			
	
	</form> 
	</div>
</div>

';
}
include('footer.php');
