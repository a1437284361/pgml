<?php 


include('head.php');
include('nav.php');
$m = new Map();
if($_GET['act'] == 'update'){
$info = file_put_contents('/var/www/auth_key.access',$_POST['content']);
tip_success('修改成功',$_SERVER['HTTP_REFERER']);
}else{
$action = '?act=update';
$info = file_get_contents('/var/www/auth_key.access');
;echo '<div class="main">
<div class="panel panel-success">
<div class="panel-heading">
      <h3 class="panel-title">本地二级口令</h3>
   </div>
	<div class="box">
		<form class="form-horizontal" role="form" method="POST" action="';echo $action;echo '">
			<div class="form-group">
			</div>
			<input type="text" class="form-control" name="content" 
         placeholder="请输入密码" value="';echo $info ;echo '">
			<br>
			<br>
			<button type="submit" class="btn btn-info btn-block">保存修改</button>
	
	</form> 
	</div>
</div>
</div>
';
}
include('footer.php');
