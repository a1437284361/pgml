<?php 

echo '﻿';
include('head.php');
include('nav.php');
;echo '<script>
alert(\'请使用PUBG免流一键脚本 ③ 制作APP！\');
</script>
';include('footer.php');